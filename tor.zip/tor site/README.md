### Dependencies
* [FontAwesome](https://github.com/FortAwesome/Font-Awesome) (v4.7.0)
* [Bootstrap](https://github.com/twbs/bootstrap) (v3.3.6)
* [jQuery](https://github.com/jquery/jquery) (v2.2.3)
* [Tilt.js](https://github.com/gijsroge/tilt.js) (v1.2.1)
* [Vegas](https://github.com/jaysalvat/vegas) (v2.2.1)
